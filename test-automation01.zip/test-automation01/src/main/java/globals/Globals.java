package globals;

public class Globals {

    public static String browserType = "chrome";

    public static String homePageUrl = "https://demo.nopcommerce.com/";
}
