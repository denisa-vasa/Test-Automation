package pages;

import elements.CellPhonesPageElements;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.BaseInformation;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CellPhonesPage {

    public CellPhonesPage() {
        PageFactory.initElements(BaseInformation.getDriver(), this);
    }

    CellPhonesPageElements cellPhonesPageElements = new CellPhonesPageElements();
    List<Double> sortedPrices = new ArrayList<>();

    public void dropDownLowToHigh(){
        Select lowToHigh = new Select(cellPhonesPageElements.sort);
        lowToHigh.selectByVisibleText("Price: Low to High");

        List<WebElement> priceElements = BaseInformation.getDriver().findElements(By.className("price"));

        List<Double> prices = new ArrayList<>();

        for(WebElement element : priceElements){
            String priceText = element.getText().replace("$", "").replace(",", "");
            double price = Double.parseDouble(priceText);
            prices.add(price);
        }

        Collections.sort(sortedPrices);
    }

    public boolean isSorted() {
        for (int i = 0; i < sortedPrices.size() - 1; i++) {
            if (sortedPrices.get(i) > sortedPrices.get(i + 1)) {
                return false;
            }
        }
        return true;
    }

    public void clickWishListButtons() {
        List<WebElement> wishlistButtons = cellPhonesPageElements.wishlist;

        for (WebElement button : wishlistButtons) {
            int attempts = 0;
            while (attempts < 3) {
                try {
                    // Scroll into view to make sure the button is clickable
                    ((JavascriptExecutor) BaseInformation.getDriver()).executeScript("arguments[0].scrollIntoView(true);", button);

                    // Wait for the element to be clickable before clicking
                    new WebDriverWait(BaseInformation.getDriver(), Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(button));

                    // Click the button
                    button.click();

                    // You may need to wait for any overlay or loading indicators to disappear
                    // Insert wait code here if necessary

                    // Break the loop if the click was successful
                    break;
                } catch (StaleElementReferenceException e) {
                    // Refresh the element reference and retry
                    button = BaseInformation.getDriver().findElement(By.xpath("//button[@class='button-2 add-to-wishlist-button' and @title='Add to wishlist']"));
                    attempts++;
                } catch (ElementClickInterceptedException e) {
                    // Handle the exception if needed
                    System.err.println("Error clicking wishlist button: " + e.getMessage());
                    break; // Break the loop to avoid infinite retries
                }
            }
        }
    }

    public boolean isNotificationDisplayed() {
        try {
            return BaseInformation.getDriver().findElement(By.className("content")).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public boolean isNumberOfProductsDisplayed() {
        try {
            return BaseInformation.getDriver().findElement(By.className("wishlist-qty")).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public void clickWishList() {
        cellPhonesPageElements.wishListMenu.click();
    }

    public boolean isNumDisplayedShoppingCart() {
        try {
            return BaseInformation.getDriver().findElement(By.className("cart-qty")).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
}
